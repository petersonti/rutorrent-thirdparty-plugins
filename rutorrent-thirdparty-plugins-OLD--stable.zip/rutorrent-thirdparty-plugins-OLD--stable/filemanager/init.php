<?php

	$theSettings->registerPlugin("filemanager");

?>