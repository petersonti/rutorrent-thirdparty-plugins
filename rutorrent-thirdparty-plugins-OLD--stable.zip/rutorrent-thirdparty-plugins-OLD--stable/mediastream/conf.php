<?php

// path on domain where a symlink to view.php can be found
// change only if you use web AUTH
// example: http://mydomain.com/stream/view.php
$streampath = 'http://mydomain.com/stream/view.php'; 


?>